import React, { Component } from 'react';
import './Login.css';

class  Login extends Component{

constructor(props){
 super(props);

 this.state = {  username: "",
            password:""       
        }
}

handleusername = (event) => {
  
   this.setState({ username: event.target.value })
 }

handlepassword = (event) => {
  
   this.setState({ password: event.target.value })
 }

 handlechangeall = (event) =>{
 this.setState ( { [event.target.name] :event.target.value  } )
}


handlesubmit = (event) => {
 alert (`my username is ${this.state.username}. 
  My password is ${this.state.password}
  `);
}


render(){
 return(
  <div class="box">
       <h1>Login</h1>


   <form onSubmit = {this.handlesubmit} >
    
    <input  type="text" name="username" placeholder="Username" value= {this.state.fullname}  
      onChange={this.handlechangeall} /> <br/>

    
    <input  type="number" name="password" placeholder="Password" value= {this.state.password} 
      onChange={this.handlechangeall} /> <br/>



<input type="submit" value="Login" />
   </form>
  </div>
 )
}

}

export default Login;

